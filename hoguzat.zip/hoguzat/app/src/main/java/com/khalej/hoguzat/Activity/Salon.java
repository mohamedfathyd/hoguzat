package com.khalej.hoguzat.Activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.khalej.hoguzat.R;

import me.anwarshahriar.calligrapher.Calligrapher;

public class Salon extends AppCompatActivity {
    RelativeLayout relativelayout2,relativelayout1;
    AppCompatTextView selectCountry;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salon);
        relativelayout1=findViewById(R.id.relativelayout);
        relativelayout2=findViewById(R.id.relativelayout2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);
        Calligrapher calligrapher = new Calligrapher(this);
        calligrapher.setFont(this, "Droid.ttf", true);
        this.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_keyboard_arrow_left_black_24dp);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                    }
                }
        );
        selectCountry=findViewById(R.id.appCompatButtonLogin);
        selectCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(Salon.this);
                dialog.setContentView(R.layout.dialog_details);
                dialog.setTitle("اختر الدولة التى تريدها");
                LinearLayout a,b,c,d,e;
                a=dialog.findViewById(R.id.a);
                b=dialog.findViewById(R.id.b);
                c=dialog.findViewById(R.id.c);
                d=dialog.findViewById(R.id.d);
                e=dialog.findViewById(R.id.e);
                a.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selectCountry.setText("البحرين");
                        dialog.dismiss();
                    }
                });
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selectCountry.setText("عمان");
                        dialog.dismiss();
                    }
                });
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selectCountry.setText("قطر");
                        dialog.dismiss();
                    }
                });
                d.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selectCountry.setText("الأمارات");
                        dialog.dismiss();
                    }
                });
                e.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selectCountry.setText("الكويت");
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
        relativelayout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Salon.this,CardView.class));
            }
        });
        relativelayout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Salon.this,CardView.class));
            }
        });
    }
}
